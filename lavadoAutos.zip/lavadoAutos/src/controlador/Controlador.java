/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Action;
import javax.swing.JComboBox;
import javax.swing.JButton;
import modelo.Modelo;
import vista.Vista;

public class Controlador implements ActionListener{
    private Vista view; private Modelo model;
      private int n,a=0,b=0;
    
      public Controlador(Vista view, Modelo model) {
        this.view = view;
        this.model = model;
        this.view.boFuncionario.addActionListener(this);
        this.view.boServicio.addActionListener(this);
        this.view.boFecha.addActionListener(this);
        this.view.ComboBox.addActionListener(this);
        this.view.boConsulta.addActionListener(this);
        this.view.bosalir.addActionListener(this);
        this.view.boLimpiar.addActionListener(this);
    }
    public void iniciar(){
     view.setLocationRelativeTo(null);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
       if(view.boServicio==e.getSource()){
            this.view.ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "lavado basico", "lavados especial","desinfeccion basica","desinfeccion avanzada" ,"combos"}));  
            this.b=0;
       }
       if(view.boFecha==e.getSource()){
           this.b=2;
       this.view.ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "23/09", "24/09", "25/09","26/09"}));
       }
       if(view.boFuncionario==e.getSource()){
              this.b=1;
       this.view.ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Funcionario l.B", "Funcionario l.E","funcionario D.B","funcionario D.A", "Funcionario combos"}));
       }
       if(view.boConsulta==e.getSource()){
                   a=view.ComboBox.getSelectedIndex();
                   if(b==0){
                   model.setServicio(a);
                   }
                   if(b==1){
                   model.setServicio(9);   
                   model.setFuncionario(a);
                   }
                   if(b==2){
                   model.setServicio(9);   
                   model.setFuncionario(9);
                   model.setFecha(a);
                   }
                   view.TextArea.append(model.lavado());
               }
       if(view.bosalir==e.getSource()){
         view.dispose(); 
       }
       if(view.boLimpiar==e.getSource()){
         view.TextArea.setText(""); 
       }
    }

    
}
