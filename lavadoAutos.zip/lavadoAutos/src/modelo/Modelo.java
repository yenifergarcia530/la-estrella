/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import controlador.Controlador;
import javax.swing.Action;
import vista.Vista;

/**
 *
 * @author Nicol PC
 */
public class Modelo {
    private int servicio,funcionario,fecha;
    private int carro=15000,camioneta=20000,totalDiac=1,totalDiaCa=1,valorF,valorF1,valorF2,totalDiac1=1,totalDiaCa1=1,totalDiac2=1,totalDiaCa2=1;
    private String auto,lavado;
    

    public Modelo() {
    }

    public int getServicio() {
        return servicio;
    }

    public void setServicio(int servicio) {
        this.servicio = servicio;
    }

    public int getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(int funcionario) {
        this.funcionario = funcionario;
    }

    public int getFecha() {
        return fecha;
    }

    public void setFecha(int fecha) {
        this.fecha = fecha;
    }

    public int getCarro() {
        return carro;
    }

    public void setCarro(int carro) {
        this.carro = carro;
    }

    public int getCamioneta() {
        return camioneta;
    }

    public void setCamioneta(int camioneta) {
        this.camioneta = camioneta;
    }

    public String getAuto() {
        return auto;
    }

    public void setAuto(String auto) {
        this.auto = auto;
    }

    public String getLavado() {
        return lavado;
    }

    public void setLavado(String lavado) {
        this.lavado = lavado;
    }

    public Modelo(String auto, String lavado) {
        this.auto = auto;
        this.lavado = lavado;
    }

    public int getTotalDiac() {
        return totalDiac;
    }

    public void setTotalDiac(int totalDiac) {
        this.totalDiac = totalDiac;
    }

    public int getTotalDiaCa() {
        return totalDiaCa;
    }

    public void setTotalDiaCa(int totalDiaCa) {
        this.totalDiaCa = totalDiaCa;
    }

    public int getValorF() {
        return valorF;
    }

    public void setValorF(int valorF) {
        this.valorF = valorF;
    }

    public int getTotalDiac1() {
        return totalDiac1;
    }

    public void setTotalDiac1(int totalDiac1) {
        this.totalDiac1 = totalDiac1;
    }

    public int getTotalDiaCa1() {
        return totalDiaCa1;
    }

    public void setTotalDiaCa1(int totalDiaCa1) {
        this.totalDiaCa1 = totalDiaCa1;
    }

    public int getTotalDiac2() {
        return totalDiac2;
    }

    public void setTotalDiac2(int totalDiac2) {
        this.totalDiac2 = totalDiac2;
    }

    public int getTotalDiaCa2() {
        return totalDiaCa2;
    }

    public void setTotalDiaCa2(int totalDiaCa2) {
        this.totalDiaCa2 = totalDiaCa2;
    }

    public int getValorF1() {
        return valorF1;
    }

    public void setValorF1(int valorF1) {
        this.valorF1 = valorF1;
    }

    public int getValorF2() {
        return valorF2;
    }

    public void setValorF2(int valorF2) {
        this.valorF2 = valorF2;
    }
    

   
    public String lavado(){
        servicio=servicio;funcionario=funcionario;fecha=fecha;
        if(servicio==0){
           totalDiaCa=5;totalDiac=6;    
          valorF=(20000+camioneta)*totalDiaCa;valorF=valorF+((20000+carro)*totalDiac);
          return "\n"+"se lavaron "+totalDiaCa+" camionetas y "+totalDiac+" carros con lavado basico"+"\n"+"y en total fue de "+valorF;
        }
        if(servicio==1){
           totalDiaCa=3;totalDiac=5;    
          valorF=(30000+camioneta)*totalDiaCa;valorF=valorF+((30000+carro)*totalDiac);
          return "\n"+"se lavaron "+totalDiaCa+" camionetas y "+totalDiac+" carros con lavado Especial"+"\n"+"y en total fue de "+valorF;
        }
        if(servicio==2){
           totalDiaCa=7;totalDiac=8;    
          valorF=(35000+camioneta)*totalDiaCa;valorF=valorF+((35000+carro)*totalDiac);
          return "\n"+"se desinfectaron "+totalDiaCa+" camionetas y "+totalDiac+" carros con desinfeccion basica"+"\n"+"y en total fue de "+valorF;
        }
        if(servicio==3){
           totalDiaCa=4;totalDiac=4;    
          valorF=(40000+camioneta)*totalDiaCa;valorF=valorF+((40000+carro)*totalDiac);
          return "\n"+"se desinfectaron "+totalDiaCa+" camionetas y "+totalDiac+" carros con desinfeccion avanzada"+"\n"+"y en total fue de "+valorF;
        }
        if(servicio==4){
           totalDiaCa=5;totalDiac=6; totalDiac1=3;totalDiaCa1=3;totalDiac2=4;totalDiaCa2=5;  
          valorF=(35000+camioneta)*totalDiaCa;valorF=valorF+((35000+carro)*totalDiac);
          valorF1=(44000+camioneta)*totalDiaCa1; valorF1=valorF1+((44000+carro)*totalDiac1);
          valorF2=(50000+camioneta)*totalDiaCa1; valorF2=valorF2+((50000+carro)*totalDiac1);
          return "\n"+totalDiaCa+" camionetas y "+totalDiac+" carros con el combo 1"+"\n"+"y en total fue de "+valorF+"\n"+"\n"+totalDiaCa1+" camionetas y "+totalDiac1+" carros con el combo 2"+"\n"+"y en total fue de "+valorF1+"\n"+"\n"+totalDiaCa2+" camionetas y "+totalDiac2+" carros con el combo 3"+"\n"+"y en total fue de "+valorF2;
          
        }
        if(funcionario==0){
        totalDiaCa=5;totalDiac=6;    
          valorF=(20000+camioneta)*totalDiaCa;valorF=valorF+((20000+carro)*totalDiac);
          return "\n"+"el funcionario juan "+" lavo "+totalDiaCa+" camionetas y "+totalDiac+" carros con lavado basico"+"\n"+"y en total fue de "+valorF;
        }
        if(funcionario==1){
        totalDiaCa=3;totalDiac=5;    
          valorF=(30000+camioneta)*totalDiaCa;valorF=valorF+((30000+carro)*totalDiac);
          return "\n"+"el funcionario kevin "+" lavo "+totalDiaCa+" camionetas y "+totalDiac+" carros con lavado Especial"+"\n"+"y en total fue de "+valorF;
        }
        if(funcionario==2){
        totalDiaCa=7;totalDiac=8;    
          valorF=(35000+camioneta)*totalDiaCa;valorF=valorF+((35000+carro)*totalDiac);
          return "\n"+"el funcionario miguel "+" desinfecto "+totalDiaCa+" camionetas y "+totalDiac+" carros con desinfeccion basica"+"\n"+"y en total fue de "+valorF;
        }
        if(funcionario==3){
         totalDiaCa=4;totalDiac=4;    
          valorF=(40000+camioneta)*totalDiaCa;valorF=valorF+((40000+carro)*totalDiac);
          return "\n"+"el funcionario andres "+" desinfecto "+totalDiaCa+" camionetas y "+totalDiac+" carros con desinfeccion avanzada"+"\n"+"y en total fue de "+valorF;
        }
        if(funcionario==4){
         totalDiaCa=5;totalDiac=6; totalDiac1=3;totalDiaCa1=3;totalDiac2=4;totalDiaCa2=5; 
          valorF=(35000+camioneta)*totalDiaCa;valorF=valorF+((35000+carro)*totalDiac);
          valorF1=(44000+camioneta)*totalDiaCa1; valorF1=valorF1+((44000+carro)*totalDiac1);
          valorF2=(50000+camioneta)*totalDiaCa1; valorF2=valorF2+((50000+carro)*totalDiac1);
          return "\n"+"el funcionario carlos "+"lavo "+totalDiaCa+" camionetas y "+totalDiac+" carros con el combo 1"+"\n"+"y en total fue de "+valorF+"\n"+"\n"+totalDiaCa1+" camionetas y "+totalDiac1+" carros con el combo 2"+"\n"+"y en total fue de "+valorF1+"\n"+"\n"+totalDiaCa2+" camionetas y "+totalDiac2+" carros con el combo 3"+"\n"+"y en total fue de "+valorF2;  
        }
        
        if(fecha==0){
         totalDiaCa=3;totalDiac=5;    
          valorF=(30000+camioneta)*totalDiaCa;valorF=valorF+((30000+carro)*totalDiac);
          totalDiac1=3;totalDiaCa1=3;
          valorF1=(40000+camioneta)*totalDiaCa1; valorF1=valorF1+((40000+carro)*totalDiac1);
          return "\n"+"se lavaron "+totalDiaCa+" camionetas y "+totalDiac+" carros con lavado Especial"+"\n"+"y en total fue de "+valorF+"\n"+"se desinfectaron "+totalDiaCa1+" camionetas y "+totalDiac1+" carros con desinfeccion avanzada"+"\n"+"y en total fue de "+valorF1;
         
        }
        if(fecha==2){
         totalDiaCa=8;totalDiac=9;    
          valorF=(30000+camioneta)*totalDiaCa;valorF=valorF+((30000+carro)*totalDiac);
          totalDiac1=5;totalDiaCa1=3;
          valorF1=(20000+camioneta)*totalDiaCa1; valorF1=valorF1+((20000+carro)*totalDiac1);
          return "\n"+"se lavaron "+totalDiaCa+" camionetas y "+totalDiac+" carros con lavado Especial"+"\n"+"y en total fue de "+valorF+"\n"+"se lavaron "+totalDiaCa1+" camionetas y "+totalDiac1+" carros con lavado basico"+"\n"+"y en total fue de "+valorF1;
         
        }
        if(fecha==3){
          totalDiaCa=5;totalDiac=5;    
          valorF=(30000+camioneta)*totalDiaCa;valorF=valorF+((30000+carro)*totalDiac);
          totalDiac1=2;totalDiaCa1=10;
          valorF1=(35000+camioneta)*totalDiaCa1; valorF1=valorF1+((35000+carro)*totalDiac1);
          return "\n"+"se lavaron "+totalDiaCa+" camionetas y "+totalDiac+" carros con lavado Especial"+"\n"+"y en total fue de "+valorF+"\n"+"se desinfectaron "+totalDiaCa1+" camionetas y "+totalDiac1+" carros con desinfeccion basica"+"\n"+"y en total fue de "+valorF1;
         
        }
        if(fecha==4){
          totalDiaCa=8;totalDiac=4;    
          valorF=(20000+camioneta)*totalDiaCa;valorF=valorF+((20000+carro)*totalDiac);
          totalDiac1=2;totalDiaCa1=9;
          valorF1=(40000+camioneta)*totalDiaCa1; valorF1=valorF1+((40000+carro)*totalDiac1);
          return "\n"+"se lavaron "+totalDiaCa+" camionetas y "+totalDiac+" carros con lavado basico"+"\n"+"y en total fue de "+valorF+"\n"+"se desinfectaron "+totalDiaCa1+" camionetas y "+totalDiac1+" carros con desinfeccion avanzada"+"\n"+"y en total fue de "+valorF1;
         
        }
     return"";  
    }
   
    
    
}
